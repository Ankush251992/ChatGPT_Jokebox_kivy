import kivy
from kivy.app import App
from kivy.lang import Builder
from kivy.properties import StringProperty
import random
import requests
import json
import os
from kivy.clock import Clock
from kivy.core.text import Label as CoreLabel
from kivy.uix.label import Label
import openai


kv = '''
BoxLayout:
    orientation: 'vertical'
    padding: 20
    spacing: 10

    ScrollView:
        size_hint_y: None
        height: joke_label.texture_size[1] + 20

        Label:
            id: joke_label
            text: app.label_text
            font_size: 18
            halign: "center"
            valign: 'middle'
            multiline: True
            size_hint_y: None
            height: self.texture_size[1]
            text_size: self.width - 20, None

    Button:
        text: "Show me a joke!"
        size_hint: 1, 0.2
        on_press: app.show_joke()

    Button:
        text: "Tell me a joke!"
        size_hint: 1, 0.2
        on_press: app.tell_joke()
'''


def fetch_joke():
    openai.api_key = "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"

    prompt = "Tell me a funny joke."

    response = openai.Completion.create(
        engine="text-davinci-002",
        prompt=prompt,
        max_tokens=100,
        n=1,
        stop=None,
        temperature=0.7,
    )

    joke = response.choices[0].text.strip()
    return joke


class JokeBoxApp(App):
    label_text = StringProperty("Press the button to get a joke!")
    shown_jokes = []

    def build(self):
        return Builder.load_string(kv)

    def show_joke(self):
        joke = fetch_joke()
        while joke in self.shown_jokes:
            joke = fetch_joke()
        self.shown_jokes.append(joke)
        self.label_text = joke

    def tell_joke(self):
        joke = fetch_joke()
        while joke in self.shown_jokes:
            joke = fetch_joke()
        self.shown_jokes.append(joke)
        self.label_text = joke
        os.system("say " + joke)

if __name__ == '__main__':
    JokeBoxApp().run()