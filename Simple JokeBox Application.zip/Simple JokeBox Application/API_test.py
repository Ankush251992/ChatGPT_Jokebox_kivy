# Import necessary modules
import kivy
from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
import random
import requests
import json

# Fetch a random joke from JokeAPI
def fetch_joke():
    url = "https://v2.jokeapi.dev/joke/Any"
    response = requests.get(url)

    if response.status_code == 200:
        joke_data = json.loads(response.text)
        if joke_data["type"] == "single":
            return joke_data["joke"]
        else:
            return f'{joke_data["setup"]} {joke_data["delivery"]}'
    else:
        return "Oops! Something went wrong. Try again later."

# Main app class
class JokeBoxApp(App):
    def build(self):
        layout = BoxLayout(orientation='vertical', padding=20, spacing=10)
        self.label = Label(text="Press the button to get a joke!", font_size=18, halign="center")
        button = Button(text="Show me a joke!", size_hint=(1, 0.2), on_press=self.show_joke)

        layout.add_widget(self.label)
        layout.add_widget(button)
        return layout

    def show_joke(self, instance):
        joke = fetch_joke()
        self.label.text = joke

# Run the app
if __name__ == '__main__':
    JokeBoxApp().run()

