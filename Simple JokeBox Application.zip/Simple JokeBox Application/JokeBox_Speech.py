import kivy
from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
import random
import requests
import json
import speech_recognition as sr
import pyttsx3

def fetch_joke():
    url = "https://v2.jokeapi.dev/joke/Any"
    response = requests.get(url)

    if response.status_code == 200:
        joke_data = json.loads(response.text)
        if joke_data["type"] == "single":
            return joke_data["joke"]
        else:
            return f'{joke_data["setup"]} {joke_data["delivery"]}'
    else:
        return "Oops! Something went wrong. Try again later."

def init_tts_engine():
    engine = pyttsx3.init()
    engine.setProperty('rate', 125)  # Speed of speech
    return engine

tts_engine = init_tts_engine()

def text_to_speech(text, engine):
    engine.say(text)
    engine.runAndWait()

def init_speech_recognizer():
    recognizer = sr.Recognizer()
    return recognizer

speech_recognizer = init_speech_recognizer()

def recognize_speech(recognizer):
    with sr.Microphone() as source:
        print("Listening...")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)

    try:
        print("Recognizing...")
        recognized_text = recognizer.recognize_google(audio)
        return recognized_text
    except Exception as e:
        print("Error:", e)
        return None

class JokeBoxApp(App):
    def build(self):
        layout = BoxLayout(orientation='vertical', padding=20, spacing=10)
        self.label = Label(text="Press the button to get a joke!", font_size=18, halign="center")
        button = Button(text="Show me a joke!", size_hint=(1, 0.2), on_press=self.show_joke)
        voice_button = Button(text="Tell me a joke!", size_hint=(1, 0.2), on_press=self.tell_joke)

        layout.add_widget(self.label)
        layout.add_widget(button)
        layout.add_widget(voice_button)
        return layout

    def show_joke(self, instance):
        joke = fetch_joke()
        self.label.text = joke

    def tell_joke(self, instance):
        recognized_text = recognize_speech(speech_recognizer)
        if recognized_text and "tell me a joke" in recognized_text.lower():
            joke = fetch_joke()
            self.label.text = joke
            text_to_speech(joke, tts_engine)
        else:
            self.label.text = "Sorry, I didn't understand. Please try again."

if __name__ == '__main__':
    JokeBoxApp().run()
