# Import necessary modules
import kivy
from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
import random

# List of jokes
jokes = [
    "Why don't scientists trust atoms? Because they make up everything!",
    "Why do we never tell secrets on a farm? Because the potatoes have eyes and the corn has ears!",
    "Why don't some couples go to the gym? Because some relationships don't work out.",
    "What do you call fake spaghetti? An impasta!",
    "Why did the scarecrow win an award? Because he was outstanding in his field!",
    # Add more jokes here
]


# Main app class
class JokeBoxApp(App):
    def build(self):
        layout = BoxLayout(orientation='vertical', padding=20, spacing=10)
        self.label = Label(text="Press the button to get a joke!", font_size=20, halign="center")
        button = Button(text="Show me a joke!", size_hint=(1, 0.2), on_press=self.show_joke)

        layout.add_widget(self.label)
        layout.add_widget(button)
        return layout

    def show_joke(self, instance):
        joke = random.choice(jokes)
        self.label.text = joke


# Run the app
if __name__ == '__main__':
    JokeBoxApp().run()
